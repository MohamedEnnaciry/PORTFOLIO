document.getElementById('submit-button').addEventListener('click', function(event) {
  event.preventDefault(); // Evita il comportamento predefinito del pulsante di invio del modulo

  var password = document.getElementById("password").value;
  if (password === "Benvenuto") {
    // Se la password è corretta, invia il modulo
    document.querySelector('form').submit();
  } else {
    // Se la password non è corretta, aggiungi la classe di errore e rimuovila dopo un po'
    var passwordInput = document.getElementById("password");
    passwordInput.classList.add("error");
    setTimeout(function() {
      passwordInput.classList.remove("error");
    }, 1500); // 1500 millisecondi = 1.5 secondi
  }
});
