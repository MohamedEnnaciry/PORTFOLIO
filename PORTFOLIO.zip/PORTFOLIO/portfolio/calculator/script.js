const display = document.querySelector('.display');
const buttons = document.querySelectorAll('button');

let currentVal = '0'; // Start with 0 on display
let operator = '';
let previousVal = '';

function handleNumber(num) {
  if (currentVal === '0') {
    currentVal = num; // Replace 0 with the first digit
  } else {
    currentVal += num; 
  }
  display.textContent = currentVal;
}

function handleOperator(op) {
  operator = op;
  previousVal = currentVal;
  currentVal = ''; // Clear currentVal for the next number
}

function handleEquals() {
  const num1 = parseFloat(previousVal);
  const num2 = parseFloat(currentVal);

  let result;
  switch (operator) {
    case '+':
      result = num1 + num2;
      break;
    case '-':
      result = num1 - num2;
      break;
    case '*':
      result = num1 * num2;
      break;
    case '/':
      result = num2 === 0 ? 'Error' : num1 / num2; // Handle division by zero
      break;
    default:
      result = currentVal;
  }

  display.textContent = result;
  currentVal = result.toString(); // Update currentVal as a string
  operator = '';
  previousVal = '';
}

function handleClear() {
  currentVal = '0';
  operator = '';
  previousVal = '';
  display.textContent = '0';
}

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const val = button.dataset.val;
    const op = button.dataset.op;

    if (val) handleNumber(val);
    else if (op === 'C') handleClear();
    else if (op === '=') handleEquals();
    else handleOperator(op);
  });
});