document.getElementById('signupButton').addEventListener('click', function() {
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        document.getElementById('password').classList.add('invalid');
        document.getElementById('confirmPassword').classList.add('invalid');
    } else {
        document.getElementById('password').classList.remove('invalid');
        document.getElementById('confirmPassword').classList.remove('invalid');
    }
});
