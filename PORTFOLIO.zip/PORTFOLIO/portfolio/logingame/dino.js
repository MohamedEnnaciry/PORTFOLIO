const dino = document.getElementById("dino");
const gameContainer = document.querySelector(".game-container");

let isJumping = false;
let isGameOver = false;
let isTouchingObstacle = false;
let obstacleIntervals = [];
let obstacleGenerator;

// Dino jump function
function jump() {
    if (isJumping || isGameOver || isTouchingObstacle) return;
    isJumping = true;
    dino.classList.add("jump");
    setTimeout(() => {
        dino.classList.remove("jump");
        isJumping = false;
    }, 1000);
}

// Event listener for jump (spacebar)
document.addEventListener("keydown", event => {
    if (event.code === "Space") {
        jump();
    }
});

// Function to generate obstacles
function generateObstacles() {
    if (isGameOver || isTouchingObstacle) return;

    const obstacle = document.createElement("div");
    const obstacleType = Math.random() > 0.5 ? "obstacle-tall" : "obstacle-short";
    obstacle.classList.add("obstacle", obstacleType);
    gameContainer.appendChild(obstacle);

    let obstaclePosition = 1000;
    let obstacleSpeed = 5;

    const moveObstacle = () => {
        if (isGameOver || isTouchingObstacle) return;

        obstaclePosition -= obstacleSpeed;
        obstacle.style.right = obstaclePosition + "px";

        if (obstaclePosition < -50) {
            obstacle.remove();
            clearInterval(obstacleInterval); // Clear interval when obstacle is removed
        }

        const dinoRect = dino.getBoundingClientRect();
        const obstacleRect = obstacle.getBoundingClientRect();
        if (dinoRect.right > obstacleRect.left &&
            dinoRect.left < obstacleRect.right &&
            dinoRect.bottom > obstacleRect.top) {
            isTouchingObstacle = true;
            clearInterval(obstacleGenerator); // Stop obstacle generation on collision
            obstacleIntervals.forEach(interval => clearInterval(interval)); // Stop all obstacle movement intervals
            gameOver();
        }
    };

    const obstacleInterval = setInterval(moveObstacle, 20);
    obstacleIntervals.push(obstacleInterval);
}

// Start generating obstacles
obstacleGenerator = setInterval(generateObstacles, 1500);

// Function to handle game over
function gameOver() {
    isGameOver = true;

    // Display "Game Over" message
    const gameOverMessage = document.createElement("div");
    gameOverMessage.textContent = "Game Over";
    gameOverMessage.classList.add("game-over-message");
    gameContainer.appendChild(gameOverMessage);

    // Create restart button
    const restartButton = document.createElement("button");
    restartButton.textContent = "Restart";
    restartButton.classList.add("restart-button");
    gameContainer.appendChild(restartButton);

    restartButton.addEventListener("click", () => {
        location.reload(); 
    });
}

// Function to check for collisions
function checkCollision() {
    if (isGameOver || isTouchingObstacle) return;

    const dinoRect = dino.getBoundingClientRect();
    const obstacles = document.querySelectorAll(".obstacle");

    for (let i = 0; i < obstacles.length; i++) {
        const obstacleRect = obstacles[i].getBoundingClientRect();
        if (dinoRect.right > obstacleRect.left &&
            dinoRect.left < obstacleRect.right &&
            dinoRect.bottom > obstacleRect.top) {
            isTouchingObstacle = true;
            clearInterval(obstacleGenerator); // Stop obstacle generation on collision
            obstacleIntervals.forEach(interval => clearInterval(interval)); // Stop all obstacle movement intervals
            gameOver();
            break;
        }
    }
}

// Start collision detection
setInterval(checkCollision, 10);
